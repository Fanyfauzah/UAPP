package com.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class CuteNotesApp {
    private static DefaultTableModel tableModel = new DefaultTableModel();
    private static List<Note> notes = new ArrayList<>();

    public static void main(String[] args) {
        // Membuat JFrame (jendela utama)
        JFrame frame = new JFrame("Cute Notes App");
        frame.setSize(700, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Panel atas untuk pencarian dan notifikasi
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(255, 182, 193)); // Warna pink terang
        topPanel.setLayout(new BorderLayout(10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextField searchField = new JTextField("Cari catatan...");
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchField.setForeground(Color.GRAY);
        searchField.setBorder(BorderFactory.createLineBorder(new Color(139, 0, 0), 2)); // Merah maroon

        JButton searchButton = new JButton("Search");
        searchButton.setBackground(new Color(139, 0, 0)); // Merah maroon
        searchButton.setForeground(Color.WHITE);
        styleButton(searchButton);

        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);

        topPanel.add(searchPanel, BorderLayout.CENTER);

        // Panel utama dengan warna latar pink
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(255, 192, 203)); // Pink
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel untuk input catatan
        JPanel inputPanel = new JPanel();
        inputPanel.setBackground(new Color(255, 192, 203)); // Pink
        inputPanel.setLayout(new BorderLayout(5, 5));

        JButton addButton = new JButton("+");
        addButton.setBackground(new Color(139, 0, 0)); // Merah maroon
        addButton.setForeground(Color.WHITE);
        styleButton(addButton);

        inputPanel.add(addButton, BorderLayout.WEST);

        // Tombol untuk menyimpan catatan ke file teks
        JButton saveButton = new JButton("Save to TXT");
        saveButton.setBackground(new Color(139, 0, 0)); // Merah maroon
        saveButton.setForeground(Color.WHITE);
        styleButton(saveButton);
        inputPanel.add(saveButton, BorderLayout.EAST);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("Catatan_Phyton.doc"))) {
                    for (Note note : notes) {
                        writer.write(note.getContent() + "|" + note.getTimestamp());
                        writer.newLine();
                    }
                    JOptionPane.showMessageDialog(frame, "Catatan berhasil disimpan ke Catatan_Phyton.doc", "Info", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println("File saved at: " + new File("Catatan_Phyton.doc").getAbsolutePath());
                } catch (IOException ioException) {
                    JOptionPane.showMessageDialog(frame, "Gagal menyimpan catatan ke file!", "Error", JOptionPane.ERROR_MESSAGE);
                    ioException.printStackTrace();
                }
            }
        });

        // Tambahkan tombol Delete
        JButton deleteButton = new JButton("Delete");
        deleteButton.setBackground(new Color(139, 0, 0)); // Merah maroon
        deleteButton.setForeground(Color.WHITE);
        styleButton(deleteButton);
        inputPanel.add(deleteButton, BorderLayout.SOUTH);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                File docFile = new File("Catatan_Phyton.doc");

                if (docFile.exists() && docFile.delete()) {
                    JOptionPane.showMessageDialog(frame, "Catatan berhasil dihapus", "Info", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Catatan berhasi ldihapus", "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Panel untuk tabel catatan
        JTable notesTable = new JTable(tableModel);
        tableModel.addColumn("Catatan");
        tableModel.addColumn("Waktu");

        JScrollPane notesScrollPane = new JScrollPane(notesTable);
        notesScrollPane.setBorder(BorderFactory.createTitledBorder("Daftar Catatan"));
        notesScrollPane.setBackground(new Color(255, 192, 203)); // Pink

        // Menambahkan komponen ke frame
        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(mainPanel, BorderLayout.CENTER);

        // Menambahkan panel input dan tabel catatan ke frame
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(notesScrollPane, BorderLayout.CENTER);

        // ActionListener untuk tombol tambah catatan
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String noteContent = JOptionPane.showInputDialog(frame, "Masukkan catatan baru:");
                if (noteContent != null && !noteContent.trim().isEmpty()) {
                    LocalDateTime now = LocalDateTime.now();
                    String formattedDate = now.format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm"));
                    Note newNote = new Note(noteContent, formattedDate);
                    notes.add(newNote);
                    tableModel.addRow(new Object[]{newNote.getContent(), newNote.getTimestamp()});
                } else {
                    JOptionPane.showMessageDialog(frame, "Catatan tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // ActionListener untuk tombol pencarian
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText().trim().toLowerCase();
                if (!query.isEmpty()) {
                    tableModel.setRowCount(0); // Clear existing rows
                    for (Note note : notes) {
                        if (note.getContent().toLowerCase().contains(query)) {
                            tableModel.addRow(new Object[]{note.getContent(), note.getTimestamp()});
                        }
                    }
                }
            }
        });

        // Menampilkan jendela
        frame.setVisible(true);
    }

    private static void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        button.setFont(new Font("Arial", Font.BOLD, 14));
    }

    static class Note {
        private final String content;
        private final String timestamp;

        public Note(String content, String timestamp) {
            this.content = content;
            this.timestamp = timestamp;
        }

        public String getContent() {
            return content;
        }

        public String getTimestamp() {
            return timestamp;
        }
    }
}
