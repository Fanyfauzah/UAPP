file = open ("Catatan_Phyton.doc","a")
file.write("Anggun,023077,2\n")
file.close()
print("Data sudah di tambahkan")