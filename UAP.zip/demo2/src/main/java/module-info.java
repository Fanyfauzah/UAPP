module com.example.demo2 {
    requires java.desktop;
    requires javafx.controls;
    requires javafx.fxml;
}
